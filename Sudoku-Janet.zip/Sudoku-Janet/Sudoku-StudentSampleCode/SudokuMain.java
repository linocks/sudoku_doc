import javax.swing.*;
/**
 *  This class is what launches the Sudoku application giving you the option
 *  to choose between the GUI or the text UI
*/
public class SudokuMain {
    /**
     * The main method to launch the Sudoku game GUI or text UI.
     *
     * @param args Command-line arguments (not used in this application).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                ButtonGroup group = new ButtonGroup();
                String msgString1 = "Select Your Preferred User Interface";

                JRadioButton radioBtnOne = new JRadioButton("GUI");
                JRadioButton radioBtnTwo = new JRadioButton("Text UI");
                radioBtnOne.setSelected(true);

                group.add(radioBtnOne);
                group.add(radioBtnTwo);

                Object[] array = {msgString1, radioBtnOne, radioBtnTwo};

                int option = (JOptionPane.showConfirmDialog(null, array,
                        "Option", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE));

                if (option == 0) {
                    int choice = radioBtnOne.isSelected() ? 1 : 2;
                    if (choice == 1) {
                        new GUI();
                    } else {
                        new UI();
                    }
                } else {
                    System.exit(1);
                }
            }
        });
    }
}
