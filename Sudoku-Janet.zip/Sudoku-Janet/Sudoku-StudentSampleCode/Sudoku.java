
import java.io.*;
import java.util.*;

/**
 * This is the class Sudoku and it handles the functionality of the main game.
 *
 * @author Lauren Scott
 * @version Student Sample Code
 */
@SuppressWarnings("deprecation")
public class Sudoku extends Observable {
    private String[][] solution;//This array stores the solution to the game
    private Slot[][] populatedBoard;//This is the board of moves for the game
    private Scanner reader;//This scanner is used to read the game and level files
    private int gameSize;    //This will be the size of the game
    private String level = "Levels/esu1.txt";//This is the level file,changable for easy and hard
    private final Stack<Slot> history = new Stack<>();
    private boolean programmaticUpdate = false;
    private boolean gameSolved = false;

    public boolean isGameSolved() {
        return gameSolved;
    }

    public void setGameSolved(boolean gameSolved) {
        this.gameSolved = gameSolved;
    }

    /**
     * This is the constructor for the class Sudoku
     */
    public Sudoku() {
        try {
            reader = new Scanner(new File(level));
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        gameSize = calculateGameSize();
        solution = new String[gameSize][gameSize];
        populatedBoard = new Slot[gameSize][gameSize];
        readLevelFile();
        loadWinSolution();
    }

    /**
     * This method gets the entire set of moves in the game
     *
     * @return the set of moves
     */
    public Slot[][] getMoves() {
        return populatedBoard;
    }

    /**
     * This method gets an individual cell's state
     *
     * @param row - the row of the move
     * @param col - the column of the move
     * @return The state of that cell
     */
    public String getIndividualMove(int row, int col) {
        return populatedBoard[row][col].getState();
    }

    /**
     * This method reads the game size from the file
     *
     * @return the size of the puzzle
     */
    public int calculateGameSize() {
        return Integer.parseInt(reader.next());
    }

    /**
     * This method provides access to the gameSize from other classes
     *
     * @return the size of the puzzle
     */
    public int getGameSize() {
        return gameSize;
    }

    /**
     * This method reads the level file to populate the game
     *
     * @return The moves stored in the file
     */
    public Slot[][] readLevelFile() {

        while (reader.hasNext()) {
            int row = Integer.parseInt(reader.next());
            int col = Integer.parseInt(reader.next());
            String move = reader.next();

            populatedBoard[row][col] = new Slot(col, row, move, false);

        }
        return populatedBoard;
    }

    /**
     * This method reads the solution file that corresponds to the level file
     */
    public void loadWinSolution() {

        Scanner reader = null;
        try {
            reader = new Scanner(new File("Solutions/esu1solution.txt"));
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        while (reader.hasNext()) {
            int row = Integer.parseInt(reader.next());
            int col = Integer.parseInt(reader.next());
            String move = reader.next();
            solution[row][col] = move;

        }

    }

    public boolean isProgrammaticUpdate() {
        return programmaticUpdate;
    }

    public void setProgrammaticUpdate(boolean b) {
        programmaticUpdate = b;
    }

    /**
     * This method checks whether the gane has been won
     *
     * @return whether the game has been won
     */
    public Boolean checkWin() {
        for (int i = 0; i < gameSize; i++) {
            for (int c = 0; c < gameSize; c++) {
                if (!populatedBoard[i][c].getState().equals(solution[i][c])) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * This method allows a user to make a move in the game
     *
     * @param row    - the row of the move
     * @param col    - the column of the move
     * @param number - the number they are wishing to enter in the cell
     * @return whether the move was valid
     */
    public Boolean makeMove(String row, String col, String number) {
        if(isGameSolved()){
            setGameSolved(false);
        }
        String enteredNumber = number.strip();
        int enteredRow = Integer.parseInt(row);
        int enteredCol = Integer.parseInt(col);
        if (populatedBoard[enteredRow][enteredCol].getFillable()) {

            if (!enteredNumber.isEmpty()) {
                populatedBoard[enteredRow][enteredCol].setState(enteredNumber);
                if (!history.contains(populatedBoard[enteredRow][enteredCol])) {
                    history.push(populatedBoard[enteredRow][enteredCol]);
                }
                setChanged();
                notifyObservers();
                return true;
            }
        }

        return false;
    }

    /**
     * Saves the game state to a file.
     *
     * @param filePath The path to the file to save the game.
     * @return True if the save was successful, false otherwise.
     */
    public boolean saveGameToFile(String filePath) {
        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < gameSize; i++)//for each row
        {
            for (int j = 0; j < gameSize; j++)//for each column
            {
                String currentState = populatedBoard[i][j].getState();
                builder.append(populatedBoard[i][j].getFillable() ? currentState + "*" : currentState);//append to the output string
                if (j < gameSize - 1)//if this is not the last row element
                    builder.append(" ");//then add comma (if you don't like commas you can use spaces)
            }
            builder.append("\n");//append new line at the end of the row
        }

//        BufferedWriter writer = null;
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
//            writer = new BufferedWriter(new FileWriter(filePath));
            writer.write(builder.toString());//save the string representation of the cells
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return true;
    }

    /**
     * Loads the game state from a file.
     *
     * @param filePath The path to the file to load the game.
     * @return True if the load was successful, false otherwise.
     */
    public boolean loadGameFromFile(String filePath) {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(filePath));
            String line = "";
            int row = 0;
            while ((line = reader.readLine()) != null) {
                String[] cols = line.split(" ");
                int col = 0;
                for (String c : cols) {
                    if (c.contains("*")) {
                        c = c.replace("*", "");
                    }
                    populatedBoard[row][col].setState(c);
                    col++;
                }
                row++;
            }
            reader.close();
            setProgrammaticUpdate(true);
            setChanged();
            notifyObservers(populatedBoard);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return true;
    }

    /**
     * Undoes the last move in the game.
     */
    public void undo() {
        if (!history.isEmpty()) {
            setProgrammaticUpdate(true);
            Slot prevPopulatedBoard = history.pop();
            populatedBoard[prevPopulatedBoard.getRow()][prevPopulatedBoard.getCol()].undoState("-");
            setChanged();
            notifyObservers(prevPopulatedBoard);
        }
    }

    /**
     * Empties a cell in the game without triggering the cell validation method.
     *
     * @param r The row of the cell.
     * @param c The column of the cell.
     */
    public void emptyCell(String r, String c){
        int row = Integer.parseInt(r);
        int col = Integer.parseInt(c);
        populatedBoard[row][col].undoState("-");
    }

    /**
     * Clears or resets the entire game board.
     */
    public void clear() {
        for (int i = 0; i < populatedBoard.length; i++) {
            for (int j = 0; j < populatedBoard[i].length; j++) {
                if (populatedBoard[i][j].getFillable()) {
                    populatedBoard[i][j].undoState("-");
                }
            }
        }
        setProgrammaticUpdate(true);
        setChanged();
        notifyObservers(populatedBoard);
    }

    /**
     * Resets the history of moves.
     */
    public void resetHistory() {
        history.clear();
    }

    public Stack<Slot> getHistory() {
        return history;
    }

}//end of class Sudoku
