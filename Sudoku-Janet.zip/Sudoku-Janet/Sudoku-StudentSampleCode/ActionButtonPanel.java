import javax.swing.*;
import java.awt.event.ActionEvent;
import java.io.File;

/**
 * ActionButtonPanel class represents the panel containing action buttons 
 * (Help, Clear, Undo, Save, Load, Quit)
 * for the Sudoku game. It extends JPanel and provides functionality for 
 * various actions in the Sudoku game.
 * @author (Janet)
 * @version (a version number or a date)
 */
public class ActionButtonPanel extends JPanel
{
    // instance variables - replace the example below with your own
    private JButton helpBtn;
    private JButton quitBtn;
    private JButton clearBtn;
    private JButton undoBtn;
    private JButton saveBtn;
    private JButton loadBtn;
    JFileChooser fileChooser;
    private Sudoku sudoku;

    /**
     * Constructor for the ActionButtonPanel class.
     *
     * @param sudoku The Sudoku object to associate with the panel.
     */
    public ActionButtonPanel(Sudoku sudoku) {
        this.sudoku = sudoku;
        fileChooser = new JFileChooser();

        helpBtn = new JButton("Help");
        clearBtn = new JButton("Clear");
        undoBtn = new JButton("Undo");
        saveBtn = new JButton("Save");
        loadBtn = new JButton("Load");
        quitBtn = new JButton("Quit");

        saveBtn.addActionListener(this::saveAction);
        helpBtn.addActionListener(e -> JOptionPane.showMessageDialog(null, help(), "Help", JOptionPane.INFORMATION_MESSAGE));
        clearBtn.addActionListener(e -> {
            int option = JOptionPane.showConfirmDialog(null, "Are you sure you want to reset the game?", "Reset ?", JOptionPane.YES_NO_OPTION);
            if (option == 0)
                sudoku.clear();
        });
        quitBtn.addActionListener(e -> {
            int option = JOptionPane.showConfirmDialog(null, "Are you sure you want quit the game?", "Quit ?", JOptionPane.YES_NO_OPTION);
            if (option == 0) {
                System.exit(1);
            }
        });
        loadBtn.addActionListener(this::loadGame);

        undoBtn.addActionListener(e -> sudoku.undo());

        setLayout(new BoxLayout(this, BoxLayout.X_AXIS));

        add(Box.createVerticalStrut(50));
        add(helpBtn);
        add(Box.createVerticalStrut(15));
        add(saveBtn);
        add(Box.createVerticalStrut(15));
        add(loadBtn);
        add(Box.createVerticalStrut(15));
        add(undoBtn);
        add(Box.createVerticalStrut(15));
        add(clearBtn);
        add(Box.createVerticalStrut(15));
        add(quitBtn);
    }


    /**
     * ActionListener for the Save button. Initiates the save action 
     * by enabling users save the game to a file.
     *
     * @param e The ActionEvent associated with the button click.
     */
    private void saveAction(ActionEvent e) {

        int status = fileChooser.showSaveDialog(null);
        if (status == 0) {
            String filePath = fileChooser.getSelectedFile().getAbsolutePath();
            System.out.println(filePath);
            if (sudoku.saveGameToFile(filePath)) {
                JOptionPane.showMessageDialog(null, "File Saved Successfully !", "Saved!", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    /**
     * ActionListener for the Load button. 
     * Initiates the load game action by enabling users 
     * load game from a file.
     *
     * @param e The ActionEvent associated with the button click.
     */
    private void loadGame(ActionEvent e){
        int status = fileChooser.showOpenDialog(null);
        if (status == 0) {
            File file = fileChooser.getSelectedFile();
            if (file.isFile()) {
                if (sudoku.loadGameFromFile(file.getAbsolutePath())) {
                    JOptionPane.showMessageDialog(null, "Game Loaded !!", "Load !", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        }
    }

    /**
     * Displays a help message about the rules of the Sudoku game.
     *
     * @return A String containing the help message.
     */
    private String help() {
        return "This is a 9x9 or 4x4 puzzle where each row / square \n" +
                " should contain the numbers 1-9 or 1-4 respectively only once. \n" +
                "This does not apply for diagonal lines. \n" +
                "You've been provided with some default inputs \n" +
                "which are not editable. Your goal is to complete \n" +
                "the puzzle with the missing numbers \n" +
                "\t\tGood Luck!!!!";
    }

}
