import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.util.Observable;
import java.util.Observer;

/**
 * This GUI class represents the graphical user interface for the Sudoku game.
 * It extends JFrame and implements the Observer interface to observe changes 
 * in the Sudoku model. *
 * @author (Janet Ebere)
 * @version (a version number or a date)
 */
@SuppressWarnings("deprecation")
public class GUI extends JFrame implements Observer
{
    // instance variables - replace the example below with your own
    private JTextField[][] grid;
    private JPanel panelGrid;
    private ActionButtonPanel buttonsPanel;
    private final int gameSize;
    private Sudoku sudoku;
    private TextFieldInputListener textFieldInputListener = new TextFieldInputListener();

    /**
     * Constructor for the GUI class. Initializes the Sudoku game, sets up the UI components,
     * and makes the GUI visible.
     */
    public GUI() {

        sudoku = new Sudoku();
        sudoku.addObserver(this);
        Slot[][] populatedBoard = sudoku.getMoves();
        gameSize = sudoku.getGameSize();

        setTitle("Sudoku Puzzle");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());


        grid = new JTextField[gameSize][gameSize];
        panelGrid = new JPanel();
        buttonsPanel = new ActionButtonPanel(sudoku);
        panelGrid.setLayout(new GridLayout(gameSize, gameSize));


        for (int i = 0; i < gameSize; i++) {
            for (int j = 0; j < gameSize; j++) {
                JTextField tf = new JTextField();

                Slot slot = populatedBoard[i][j];
                tf.getDocument().addDocumentListener(textFieldInputListener);
                tf.setHorizontalAlignment(JTextField.CENTER);
                tf.setName(i + "," + j);
                tf.setText(slot.getState().equals("-") ? "" : slot.getState());
                tf.setEditable(slot.getFillable());


                grid[i][j] = tf;
                panelGrid.add(grid[i][j]);
            }
        }

        add(buttonsPanel, BorderLayout.NORTH);
        add(panelGrid, BorderLayout.CENTER);
        setLocationRelativeTo(null);
        setVisible(true);
    }

     /**
     * Update method called by the Sudoku model when the state changes.
     *
     * @param o   The Observable object (Sudoku model).
     * @param arg The argument passed by the Observable (Sudoku model).
     */
    @Override
    public void update(Observable o, Object arg) {
        if (arg != null) {

            if (arg.getClass().isArray()) {
                Slot[][] newBoardState = (Slot[][]) arg;
                refreshGUI(newBoardState);
                sudoku.resetHistory();
            } else {
                Slot slot = (Slot) arg;
                int row = slot.getRow();
                int col = slot.getCol();
                if (sudoku.isProgrammaticUpdate()) {
                    grid[row][col].getDocument().removeDocumentListener(textFieldInputListener);
                    grid[row][col].setText(" ");
                    grid[row][col].getDocument().addDocumentListener(textFieldInputListener);
                    sudoku.setProgrammaticUpdate(false);
                }
            }
        }

        if (sudoku.checkWin() && !sudoku.isGameSolved()) {
            sudoku.setGameSolved(true);
            JOptionPane.showMessageDialog(null, "You've solved the puzzle successfully", "Congratulations!!!", JOptionPane.INFORMATION_MESSAGE);
        }

    }

    /**
     * Refreshes the GUI with the updated state of the Sudoku board.
     *
     * @param populatedBoard The updated state of the Sudoku board.
     */
    public void refreshGUI(Slot[][] populatedBoard) {
        for (int i = 0; i < gameSize; i++) {
            for (int j = 0; j < gameSize; j++) {
                if (populatedBoard[i][j].getFillable()) {
                    String state = populatedBoard[i][j].getState();
                    if (sudoku.isProgrammaticUpdate()) {
                        grid[i][j].getDocument().removeDocumentListener(textFieldInputListener);
                        grid[i][j].setText(state.equals("-") ? "" : state);
                        grid[i][j].getDocument().addDocumentListener(textFieldInputListener);
                    }
                }
            }
        }
        sudoku.setProgrammaticUpdate(false);
    }

    /**
     * This Inner class represents a DocumentListener for the JTextFields in the Sudoku grid.
     * and enables us make a move when the user enters a number
     */
    class TextFieldInputListener implements DocumentListener {

        /**
         * this method is invoked when text is inserted into the document.
         *
         * @param e The DocumentEvent describing the insertion.
         */
        @Override
        public void insertUpdate(DocumentEvent e) {
            JTextField textField = getEventTextField(e);
            if (textField != null) {
                String tfName = textField.getName();

                String[] pos = tfName.split(",");
                if (!sudoku.makeMove(pos[0], pos[1], textField.getText().trim())) {
                    textField.setText(" ");
                }
            }
        }

        /**
         * THis method is invoked when text is removed from the document.
         *
         * @param e The DocumentEvent describing the removal.
         */
        @Override
        public void removeUpdate(DocumentEvent e) {
            JTextField textField = getEventTextField(e);

            if (sudoku.isProgrammaticUpdate()) {
                textField.getDocument().removeDocumentListener(textFieldInputListener);
                textField.setText("");
                sudoku.setProgrammaticUpdate(false);
                textField.getDocument().addDocumentListener(textFieldInputListener);

            } else {
                String tfName = textField.getName();

                String[] pos = tfName.split(",");
                String newValue = textField.getText().trim();
                if (textField.getText().equals("")) {
                    //undo populatedBoard
                    sudoku.emptyCell(pos[0], pos[1]);
                } else {
                    sudoku.makeMove(pos[0], pos[1], newValue);
                }

            }
        }

        @Override
        public void changedUpdate(DocumentEvent e) {
        }

        /**
         * THis method retrieves the JTextField associated with the given DocumentEvent.
         *
         * @param e The DocumentEvent for which to retrieve the associated JTextField.
         * @return The JTextField associated with the DocumentEvent, or null if not found.
         */
        public JTextField getEventTextField(DocumentEvent e) {
            JTextField textField = null;
            for (int i = 0; i < gameSize; i++) {
                for (int j = 0; j < gameSize; j++) {
                    if (grid[i][j] != null && e.getDocument() == grid[i][j].getDocument()) {
                        textField = grid[i][j];
                        break;
                    }
                }
                if (textField != null) {
                    break;
                }
            }
            return textField;
        }
    }
    
    public static void main(String[] args){
        new GUI();
    }

}
