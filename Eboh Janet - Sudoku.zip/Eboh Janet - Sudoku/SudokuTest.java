

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class SudokuTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SudokuTest
{
    private Sudoku sudoku;
    
    /**
     * Default constructor for test class SudokuTest
     */
    public SudokuTest()
    {
        sudoku = new Sudoku();
    }
  
    @org.junit.jupiter.api.BeforeEach
    void setUp() {
    }

    @org.junit.jupiter.api.Test
    void getMoves() {
        assertNotNull(sudoku.getMoves());
    }

    @org.junit.jupiter.api.Test
    void getIndividualMove() {
        assertNotNull(sudoku.getIndividualMove(0, 0));
    }


    @org.junit.jupiter.api.Test
    void getGameSize() {
        assertEquals(4, sudoku.getGameSize());
    }

    @org.junit.jupiter.api.Test
    void readLevelFile() {
        assertNotNull(sudoku.readLevelFile());
    }


    @org.junit.jupiter.api.Test
    void isProgrammaticUpdate() {
        assertFalse(sudoku.isProgrammaticUpdate());
    }

    @org.junit.jupiter.api.Test
    void setProgrammaticUpdate() {
        sudoku.setProgrammaticUpdate(true);
        assertTrue(sudoku.isProgrammaticUpdate());
    }

    @org.junit.jupiter.api.Test
    void checkWin() {
        assertFalse(sudoku.checkWin());
    }

    @org.junit.jupiter.api.Test
    void makeMove() {
        assertFalse(sudoku.makeMove("0", "0", "1"));
        assertTrue(sudoku.makeMove("0", "1", "3"));
    }

    @org.junit.jupiter.api.Test
    void saveGameToFile() {
        assertTrue(sudoku.saveGameToFile("testSave.txt"));
    }

    @org.junit.jupiter.api.Test
    void loadGameFromFile() {
        assertTrue(sudoku.loadGameFromFile("backup/sudoku_backup.txt"));
    }

    @org.junit.jupiter.api.Test
    void undo() {
        System.out.println(sudoku.makeMove("1", "2", "3"));
        assertEquals("3", sudoku.getIndividualMove(1, 2));
        sudoku.undo();
        assertEquals("-", sudoku.getIndividualMove(1, 2));
    }

    @org.junit.jupiter.api.Test
    void emptyCell() {
        sudoku.emptyCell("0", "0");
        assertEquals("-", sudoku.getIndividualMove(0, 0));
    }

    @org.junit.jupiter.api.Test
    void clear() {
        sudoku.makeMove("0", "1", "1");
        sudoku.makeMove("1", "2", "3");
        sudoku.clear();
        assertEquals("-", sudoku.getIndividualMove(0, 1));
        assertEquals("-", sudoku.getIndividualMove(0, 1));
    }

    @org.junit.jupiter.api.Test
    void resetHistory() {
        sudoku.makeMove("0", "1", "1");
        assertEquals(1, sudoku.getHistory().size());
        sudoku.resetHistory();
        assertEquals(0, sudoku.getHistory().size());
    }

    
}

